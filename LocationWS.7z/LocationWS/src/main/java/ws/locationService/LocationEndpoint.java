package ws.locationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import io.spring.guides.gs_producing_web_service.GetLocationRequest;
import io.spring.guides.gs_producing_web_service.GetLocationResponse;

@Endpoint
public class LocationEndpoint {
	private static final String NAMESPACE_URI = "http://spring.io/guides/gs-producing-web-service";

	private LocationRepository countryRepository;

	@Autowired
	public LocationEndpoint(LocationRepository countryRepository) {
		this.countryRepository = countryRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getLocationRequest")
	@ResponsePayload
	public GetLocationResponse getCountry(@RequestPayload GetLocationRequest request) throws Exception {
		GetLocationResponse response = new GetLocationResponse();
		response.setLocation(countryRepository.findLocation(request.getName()));
		

		return response;
	}
}

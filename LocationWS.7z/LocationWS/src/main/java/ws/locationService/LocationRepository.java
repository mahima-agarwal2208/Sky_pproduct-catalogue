package ws.locationService;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import io.spring.guides.gs_producing_web_service.Location;

/*
 * This class acts as teh repository for the customer location.
 */
@Component
public class LocationRepository {
	private static final List<Location> countries = new ArrayList<Location>();

	/*
	 * Populates the location dummy data for the customer.
	 */
	@PostConstruct
	public void initData() {
		Location london = new Location();
		london.setCustId("Mahima");
		london.setName("London");		
		countries.add(london);

		Location liverpool = new Location();
		liverpool.setCustId("stephane");
		liverpool.setName("Liverpool");

		countries.add(liverpool);
		
	}

	/*
	 * Matches the customer location for the logged in customer based on its id
	 * 
	 * @param  	name  	   customerID of the user
	 * @return  Location   Location of the customer	
	 */
	public Location findLocation(String name) {

		Location result = null;

		for (Location location : countries) {
			if (name.equals(location.getCustId())) {
				result = location;
				break;
			}
		}

		return result;
	}
}

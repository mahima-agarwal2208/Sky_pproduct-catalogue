package ws.productService;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import io.spring.guides.gs_producing_web_service.NewsChannel;
import io.spring.guides.gs_producing_web_service.Product;
import io.spring.guides.gs_producing_web_service.SportsChannel;

/*
 * This class acts as the repository for the products to be shown on the screen.
 * Its called by product WS to pull the data.
 */
@Component
public class ProductRepository {
	private static final List<Product> products = new ArrayList<Product>();
	/*
	 * Populate dummy data for sports and news channel
	 */
	@PostConstruct
	public void initData() {
		Product product1 = new Product();
		List<String> newsChannelList = new ArrayList<>();
		newsChannelList.add("Sky TV");
		newsChannelList.add("News TV");
		
		SportsChannel sportsChannel1 = new SportsChannel();
		NewsChannel newsChannel1 =  new NewsChannel();		
		sportsChannel1.setLocation("London");	
		sportsChannel1.setChanelNamel("Arsenal TV");
		product1.setSportsChannel(sportsChannel1);		
		newsChannel1.getChanelNamel().addAll(newsChannelList);
		product1.setNewsChannel(newsChannel1);
		products.add(product1);

		Product product2 = new Product();
		SportsChannel sportsChannel2 = new SportsChannel();
		NewsChannel newsChannel2 =  new NewsChannel();
		sportsChannel2.setLocation("London");	
		sportsChannel2.setChanelNamel("Chelsea TV");
		product2.setSportsChannel(sportsChannel2);		
		newsChannel2.getChanelNamel().addAll(newsChannelList);
		product2.setNewsChannel(newsChannel2);
		products.add(product2);
		
		Product product3 = new Product();
		SportsChannel sportsChannel3 = new SportsChannel();
		NewsChannel newsChannel3 =  new NewsChannel();
		sportsChannel3.setLocation("Liverpool");	
		sportsChannel3.setChanelNamel("Liverpool TV");
		product3.setSportsChannel(sportsChannel3);
		newsChannel3.getChanelNamel().addAll(newsChannelList);
		product3.setNewsChannel(newsChannel3);
		products.add(product3);
		
		
	}

	/*
	 *Finds the products based on customer location.
	 *
	 *@param   location  		 Hold the location of the logged in customer
	 *@return  List<Product>	 Hold the list of matched products for the location.
	 */
	public List<Product> findProduct(String location) {		
		List<Product> productList = new ArrayList<Product>();
		
		for (Product product : products) {
			if (location.equals(product.getSportsChannel().getLocation())) {
				productList.add(product);
			}
		}
		return productList;
	}
}

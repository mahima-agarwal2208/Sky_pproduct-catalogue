package ws.productService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import io.spring.guides.gs_producing_web_service.GetProductRequest;
import io.spring.guides.gs_producing_web_service.GetProductResponse;

@Endpoint
public class ProductEndpoint {
	private static final String NAMESPACE_URI = "http://spring.io/guides/gs-producing-web-service";

	private ProductRepository productRepository;

	@Autowired
	public ProductEndpoint(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getProductRequest")
	@ResponsePayload
	public GetProductResponse getCountry(@RequestPayload GetProductRequest request) {
		GetProductResponse response = new GetProductResponse();
		try {
			response.getProduct().addAll(productRepository.findProduct(request.getName()));
			
		} catch (Exception e) {
			
		}

		return response;
	}
}

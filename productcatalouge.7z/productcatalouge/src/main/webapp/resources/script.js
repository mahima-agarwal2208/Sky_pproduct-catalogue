

	function preventBack(){window.history.forward();}
		setTimeout("preventBack()", 0);
		window.onunload=function(){null};

  function handleClick(cb) {
	  
	  var div = document.getElementById('selection');
	  var currentVal = '<br>' + '- '+ cb.value +'<br>';
	  var innerHTML = div.innerHTML ;
	  if (cb.checked){		  
	  	div.innerHTML =  div.innerHTML + currentVal;	  	
	  	
	  } else{
		  if(innerHTML.includes(currentVal)){
			  div.innerHTML = innerHTML.replace(currentVal, '');
		  }
	  }
	  
	}
  

  
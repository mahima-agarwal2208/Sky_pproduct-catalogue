package com.sky.Model;

/*
 * This class is the model class to show the data on the screen
 */
public class DisplayInfo {
	
	/*
	 * Holds list of sports channel that need to be shown to the user
	 */
			
	private Sports sportsChannel;
	
	/*
	 * Holds list of News channel that need to be shown to the user
	 */
	private News newsChannels;
	
	/*
	 * Holds the customer id in a hidden variable, to be shown on confirmation page
	 */
	private String hiddenCustID;
	
	public Sports getSportsChannel() {
		return sportsChannel;
	}

	public void setSportsChannel(Sports sportsChannel) {
		this.sportsChannel = sportsChannel;
	}

	public News getNewsChannels() {
		return newsChannels;
	}

	public void setNewsChannels(News newsChannels) {
		this.newsChannels = newsChannels;
	}
	
	public String getHiddenCustID() {
		return hiddenCustID;
	}

	public void setHiddenCustID(String hiddenCustID) {
		this.hiddenCustID = hiddenCustID;
	}
	
	

}

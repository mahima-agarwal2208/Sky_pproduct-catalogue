package com.sky.Model;

import java.util.List;

public class News {
	private List<String> newsChannelList;

	public List<String> getNewsChannelList() {
		return newsChannelList;
	}

	public void setNewsChannelList(List<String> newsChannelList) {
		this.newsChannelList = newsChannelList;
	}

	private String [] selected;

	public String[] getSelected() {
		return selected;
	}

	public void setSelected(String[] selected) {
		this.selected = selected;
	}

}

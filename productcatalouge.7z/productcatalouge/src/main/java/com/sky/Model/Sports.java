package com.sky.Model;

import java.util.List;

public class Sports {
	private List<String> sportsChannelList;

	public List<String> getSportsChannelList() {
		return sportsChannelList;
	}

	public void setSportsChannelList(List<String> sportsChannelList) {
		this.sportsChannelList = sportsChannelList;		
	}

	private String [] selected;

	public String[] getSelected() {
		return selected;
	}

	public void setSelected(String[] selected) {
		this.selected = selected;
	}
	
}

package com.sky.ws.Product;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class ProductConfiguration {

	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("wsClasses");
		return marshaller;
	}

    @Bean
	public ProductServiceClient productClient(Jaxb2Marshaller marshaller) {
		ProductServiceClient productClient = new ProductServiceClient();
		productClient.setDefaultUri("http://localhost:9001/ws/");
		productClient.setMarshaller(marshaller);
		productClient.setUnmarshaller(marshaller);
		return productClient;
	}

}
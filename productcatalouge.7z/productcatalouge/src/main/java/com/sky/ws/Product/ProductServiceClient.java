package com.sky.ws.Product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import wsClasses.GetProductRequest;
import wsClasses.GetProductResponse;



public class ProductServiceClient extends WebServiceGatewaySupport {
	
	private static final Logger log = LoggerFactory.getLogger(ProductServiceClient.class);
	
	public GetProductResponse getProduct(String custId) {

		GetProductRequest request = new GetProductRequest();
		request.setName(custId);

		log.info("Requesting location for " + custId);

		GetProductResponse response = (GetProductResponse) getWebServiceTemplate()
				.marshalSendAndReceive(
						"http://localhost:9001/ws/products",
						request,
						new SoapActionCallback("http://localhost:9001/ws/products"));

		return response;
	}

	

}
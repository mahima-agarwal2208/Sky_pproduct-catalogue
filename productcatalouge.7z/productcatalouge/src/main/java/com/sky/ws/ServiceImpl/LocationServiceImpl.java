//package com.sky.ws.ServiceImpl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.sky.ws.Location.LocationServiceClient;
//
//import wsClasses.GetLocationResponse;
//
//@Service
//public class LocationServiceImpl {
//	
////	@Autowired
////	LocationServiceClient locationClient;
//	
//	public String getLocation(String custID) throws Exception{
//		String location = null;   
//	    GetLocationResponse response = locationClient.getLocation(custID);
//		if(response != null && response.getLocation() != null){
//			location = response.getLocation().getName();
//		}
//		
//		return location;
//	}
//
//}

package com.sky.ws.Location;


import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
@EnableAutoConfiguration
public class LocationConfiguration {

	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("wsClasses");
		return marshaller;
	}

	@Bean
	public LocationServiceClient locationClient(Jaxb2Marshaller marshaller) {
		LocationServiceClient locationClient = new LocationServiceClient();
		locationClient.setDefaultUri("http://localhost:9000/ws/");
		locationClient.setMarshaller(marshaller);
		locationClient.setUnmarshaller(marshaller);
		return locationClient;
	}

}
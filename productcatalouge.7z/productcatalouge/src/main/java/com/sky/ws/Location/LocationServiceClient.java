package com.sky.ws.Location;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import wsClasses.GetLocationRequest;
import wsClasses.GetLocationResponse;


public class LocationServiceClient extends WebServiceGatewaySupport {
	
	private static final Logger log = LoggerFactory.getLogger(LocationServiceClient.class);
	
	public GetLocationResponse getLocation(String custId) {

		GetLocationRequest request = new GetLocationRequest();
		request.setName(custId);

		log.info("Requesting location for " + custId);

		GetLocationResponse response = (GetLocationResponse) getWebServiceTemplate()
				.marshalSendAndReceive(
						"http://localhost:9000/ws/countries",
						request,
						new SoapActionCallback("http://localhost:9000/ws/countries"));

		return response;
	}

	

}
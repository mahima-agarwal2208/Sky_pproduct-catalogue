package com.sky.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sky.Model.DisplayInfo;
import com.sky.Model.News;
import com.sky.Model.Sports;
import com.sky.ws.Location.LocationServiceClient;
import com.sky.ws.Product.ProductServiceClient;

import wsClasses.GetLocationResponse;
import wsClasses.GetProductResponse;
import wsClasses.Product;

@Controller
@RequestMapping("/user_list.html")
public class ProductCatalogueController  {
	
	@Autowired
	LocationServiceClient locationClient;
	
	@Autowired
	ProductServiceClient productClient;
	
	/*
	 * This method is called when the user wants to choose product. The customer id 
	 * is stored in the browser cookies by the name custId. This value will be passed to 
	 * the web-service to fetch location based on the cookie value.
	 */
	@RequestMapping(method = RequestMethod.GET)	 
	public String initForm(Model model, @CookieValue(value = "custID", 
			defaultValue = "Stephane") String custIdCookie) {
	
	String location = getLocation(custIdCookie);
	if(location == null){
		 return "index";
	}
	List<String> sportsChannelList = new ArrayList<>();
	List<Product> productList = getProduct(location);
	DisplayInfo dsInfo = new DisplayInfo();
	dsInfo.setHiddenCustID(custIdCookie);
    Sports sportsChannel = new Sports();
    for(Product product:productList){
    	sportsChannelList.add(product.getSportsChannel().getChanelNamel());
    }
    sportsChannel.setSportsChannelList(sportsChannelList);
    dsInfo.setSportsChannel(sportsChannel);
    News newsChannels = new News();
    if(productList != null && productList.size() > 0){
    	 newsChannels.setNewsChannelList(productList.get(0).getNewsChannel().getChanelNamel());
    }   
    dsInfo.setSportsChannel(sportsChannel);
    dsInfo.setNewsChannels(newsChannels);
    model.addAttribute("dsInfo", dsInfo);
    model.addAttribute("sportsChannel", sportsChannel);
    model.addAttribute("newsChannels", newsChannels);
    return "user_list";
}

	@RequestMapping(method = RequestMethod.POST)
    public String submitForm(Model model, DisplayInfo dsInfo,
            BindingResult result) {
        model.addAttribute("dsInfo", dsInfo);
        return "confirmation";
    }

	/*
	 * Gets the location from webservice based on the customer ID
	 */
	private String getLocation(String custId){
		String location = null; 
		//LocationServiceClient locationClient = new LocationServiceClient();
	    GetLocationResponse response = locationClient.getLocation(custId);
		if(response != null && response.getLocation() != null){
			location = response.getLocation().getName();
		}
		
		
		return location;
	}
	
	/*
	 * Gets the location from webservice based on the customer ID
	 */
	private List<Product> getProduct(String location){
		List<Product> productResponseList = null; 
	    GetProductResponse response = productClient.getProduct(location);
		if(response != null && response.getProduct() != null){
			productResponseList = response.getProduct();			
		}		
		return productResponseList;
	}

}

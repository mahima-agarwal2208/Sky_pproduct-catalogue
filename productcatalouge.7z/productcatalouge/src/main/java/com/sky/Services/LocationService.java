package com.sky.Services;

import wsClasses.Location;
import wsClasses.Product;

public interface LocationService {
	
	/*
	 * Gets the location from Location web-service, based on the customer id provided.
	 * 
	 * @param   custID(String) 		custID accepts the customer id of the user
	 * @return  location(Location)  returns the matched Location object based on teh 
	 * 								customer id.
	 * 
	 * @throws Exception            failure Exception if the location could not be found
	 * 								for the customer.		
	 */
	public String getLocation(String custID) throws Exception;
	

}

package com.sky.Services;


import wsClasses.Product;

public interface ProductService {
	
	/*
	 * Gets the Product from Product web-service, based on the location of the
	 * customer.
	 * 
	 * @param   location(String) 	accepts the location of the customer
	 * @return  Product				returns the matched Location object based on teh 
	 * 								customer id.
	 * 
	 * @throws Exception            failure Exception if the location could not be found
	 * 								for the customer.		
	 */
	
	public Product getProduct(String location) throws Exception;

}
